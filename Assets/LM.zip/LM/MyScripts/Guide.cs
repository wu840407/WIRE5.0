﻿using UnityEngine;
using System.Collections;

public class Guide : MonoBehaviour {
	// set in inspector
	public int order;
	public float guideLength;
	public Transform combinedTransform;
	public Transform gunTransform;
	public Guide masterGuide;
    //private GameObject score1;
	public static int assemblyNumber = 0;

	public bool isGrabed;
	public bool isGuided;
	public bool isCombined;
	public bool isCollideWithGun;
    public bool isFinished;

	public Grab handGrab;

	private Vector3 displacement;
	private float cos;
	private float distanceToMaster;
	private float distanceToMasterLine;

    void Awake() {
        //score1=GameObject.Find("機箱蓋總成(7)");
        isFinished = false;
    }
	
	// Update is called once per frame
	void LateUpdate () {
		if (handGrab == null || combinedTransform == null) {
			return;
		}

		/*if (order == assemblyNumber) {
			setGunDisplacement ();
			setCos ();
			setDistanceToMasterLine ();
			setDistanceToMaster ();

			if (Grab.numberOfHandGrabGun == 2 && distanceToMaster > 0.01f) {
				transform.SetParent (null);
				isCombined = false;
				isGuided = true;
				Grab.numberOfHandGrabGun--;
				assemblyNumber--;
				handGrab.withHandTransform.position = combinedTransform.position + combinedTransform.forward * 0.015f;
				handGrab.withHandTransform.rotation = combinedTransform.rotation;
				handGrab.myGrabTransform = transform;
				gameObject.AddComponent<Rigidbody> ();
				gameObject.GetComponent<Rigidbody> ().useGravity = false;
				gameObject.GetComponent<Rigidbody> ().drag = 100;
				gameObject.GetComponent<Rigidbody> ().angularDrag = 100;
			}
		}else */
        if (order == assemblyNumber + 1) {
			setDisplacement ();
			setCos ();
			setDistanceToMasterLine ();
			setDistanceToMaster ();

			if (handGrab.anotherGrab.myGrabTransform != null) {
                if (handGrab.anotherGrab.myGrabTransform.GetComponent<Guide>().isCombined)
                {
                    if (isGuided)
                    {
                        if (distanceToMasterLine > 0.22f && distanceToMaster > guideLength)
                        {
                            isGuided = false;
                        }
                        else
                        {
                            transform.rotation = combinedTransform.rotation;

                            if (distanceToMaster < 0.01f)
                            {
                                isCombined = true;

                                Grab.numberOfHandGrabGun++;
                                assemblyNumber++;
                                transform.position = combinedTransform.position;
                                transform.SetParent(gunTransform);
                                handGrab.myGrabTransform = gunTransform;
                                handGrab.withHandTransform.position = gunTransform.position;
                                handGrab.withHandTransform.rotation = gunTransform.rotation;
                                isGuided = false;
                                Destroy(gameObject.GetComponent<Rigidbody>());
                                /*
                                if (order == 7)
                                {
                                    score1.GetComponent<score>().count = 1;
                                }
                                */
                                isFinished = true;


                            }
                            else
                            {
                                transform.position = combinedTransform.position + combinedTransform.forward * distanceToMaster;
                            }
                        }
                    }
                    else
                    {
                        if (Quaternion.Dot(transform.rotation, combinedTransform.rotation) > 0.7f)
                        {
                            if (distanceToMasterLine < 0.18f && distanceToMaster > guideLength)
                            {
                                isGuided = true;
                            }
                        }
                    }
                }
			}
		}
	}

	/*private void setGunDisplacement (){
		displacement = handGrab.withHandTransform.position - gunTransform.position;
        Debug.Log(displacement);
    }*/

	private void setDisplacement () {
		displacement = handGrab.withHandTransform.transform.position - combinedTransform.position;
        
    }

	private void setCos () {
		cos = Vector3.Dot(combinedTransform.forward, displacement) / (combinedTransform.forward.magnitude * displacement.magnitude);
	}

	private void setDistanceToMasterLine () {
		float sin = Mathf.Pow (1.0f - cos * cos, 1.0f / 2.0f);
		distanceToMasterLine = displacement.magnitude * sin;
	}

	private void setDistanceToMaster () {
		if (cos > 0.0f) {
			distanceToMaster =  displacement.magnitude * cos;
		}else {
			distanceToMaster = 0.0f;
		}
	}
}
