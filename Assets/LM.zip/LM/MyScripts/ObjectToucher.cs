﻿using UnityEngine;
using System.Collections;

public class ObjectToucher : MonoBehaviour {
	[SerializeField]private int index;	//index of the finger

	private ToucherContainer toucherContainer;

	void Start () {
		toucherContainer = transform.parent.GetComponent<ToucherContainer> ();
	}

	void OnCollisionEnter (Collision collision) {
		toucherContainer.SetFingerTouch (index, true);	//set finger is touching other object
	}

	void OnCollisionExit (Collision collision) {
		toucherContainer.SetFingerTouch (index, false);	//unset finger is touching other object
	}
}
