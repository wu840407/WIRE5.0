﻿using UnityEngine;
using System.Collections;

public class ToucherContainer : MonoBehaviour {
	private bool[] fingerTouch = new bool[]{false, false, false, false, false};

	public void SetFingerTouch(int index, bool boolean) {
		fingerTouch [index] = boolean;
	}

	public bool GetFingerTouch(int index) {
		return fingerTouch [index];
	}
}
