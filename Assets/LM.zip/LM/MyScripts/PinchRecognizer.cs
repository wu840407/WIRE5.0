﻿using UnityEngine;
using System.Collections;
using Leap.Unity;

public class PinchRecognizer : MonoBehaviour {
	
	public float pinchDistance;

	private HandModel myHandModel;

	// Use this for initialization
	void Start () {
		myHandModel = transform.GetComponent<HandModel> ();
	}
	
	// Update is called once per frame
	void Update () {
		Vector3[] fingerPosition = new Vector3[4];
		float[] fingerDistance = new float[3];

		for (int i = 0; i < 3; i++) {
			fingerPosition[i] = myHandModel.fingers [i].GetBoneCenter (3);
		}

		for (int i = 0; i < 3; i++) {
			fingerDistance [i] = (fingerPosition [i + 1] - fingerPosition [0]).magnitude;
		}

		pinchDistance = fingerDistance [0];
		if (pinchDistance > fingerDistance [1]) {
			pinchDistance = fingerDistance [1];
		}
		if (pinchDistance > fingerDistance [2]) {
			pinchDistance = fingerDistance [2];
		}
	}
}
