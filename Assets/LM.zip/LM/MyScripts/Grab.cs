﻿using UnityEngine;
using System.Collections;
using Leap.Unity;

public class Grab : MonoBehaviour {
	// set in inspector
	public Transform withHandTransform;
	// default scripts
	private ToucherContainer myToucherContainer;
	private HandModel myHandModel;
	public Grab anotherGrab;
	private PinchRecognizer myPinchRecognizer;
    [SerializeField]private float minimonGrabPinch;

	public bool isGrabing;
	public static int numberOfHandGrabGun;
	private float grabPinch;

	// The gun hand grabed
	public Transform myGrabTransform;
	public Transform handTransform;
	private Guide gunGuide;

	// Use this for initialization
	void Start () {
		isGrabing = false;
		numberOfHandGrabGun = 0;
		handTransform = transform.parent;
		myToucherContainer = handTransform.GetComponent<ToucherContainer> ();
		myHandModel = handTransform.GetComponent<HandModel> ();
		myPinchRecognizer = handTransform.GetComponent<PinchRecognizer> ();
	}

	void OnCollisionStay (Collision collision) {
		if (!isGrabing) {
			myGrabTransform = collision.collider.transform.parent;
			if (myGrabTransform.tag != "Gun") {
				myGrabTransform = null;
			}
		}
	}
    bool t = false;
    float COUNT = 0;
    // Update is called once per frame
    void Update () {
        if (t)
        {
           
            if (COUNT < 1)
            {
                COUNT += Time.deltaTime;
            }
            else
            {
                enableCollider();
                t = false;
            }
           
        }
		if (myGrabTransform == null) {
			return;
		}
		if (!isGrabing) {
			gunGuide = myGrabTransform.GetComponent<Guide> ();
			if (gunGuide.isGrabed) {
				myGrabTransform = null;
				gunGuide = null;
			}else if ((myPinchRecognizer.pinchDistance < 0.22f && (myToucherContainer.GetFingerTouch (1) || myToucherContainer.GetFingerTouch (2) || myToucherContainer.GetFingerTouch (3))) && minimonGrabPinch > myPinchRecognizer.pinchDistance) {
                isGrabing = true;
				gunGuide.isGrabed = true;
				gunGuide.handGrab = transform.GetComponent<Grab> ();

				if (gunGuide.isCombined) {
					myGrabTransform = gunGuide.gunTransform;
					if (anotherGrab.gunGuide != null) {
						if (anotherGrab.gunGuide.isCombined) {
							numberOfHandGrabGun = 2;
						} else {
							numberOfHandGrabGun = 1;
						}
					}else {
						numberOfHandGrabGun = 1;
					}
				}

				withHandTransform.position = myGrabTransform.position;
				withHandTransform.rotation = myGrabTransform.rotation;

				grabPinch = myPinchRecognizer.pinchDistance;
                if (grabPinch < 0.11f) {
                    grabPinch = 0.11f;
                }

				disableCollider ();
			} else {
				myGrabTransform = null;
				gunGuide.handGrab = null;
				gunGuide = null;
			}
		}else {
			if (!gunGuide.isGuided && !(gunGuide.isCombined && (numberOfHandGrabGun == 2 && gunGuide.order > anotherGrab.gunGuide.order))) {
				myGrabTransform.position = withHandTransform.position;
				myGrabTransform.rotation = withHandTransform.rotation;
			}
			if (myPinchRecognizer.pinchDistance > grabPinch) {
				if (gunGuide.isCombined) {
					if (anotherGrab.gunGuide != null && anotherGrab.gunGuide.isCombined) {
						numberOfHandGrabGun = 1;

						anotherGrab.withHandTransform.position = gunGuide.gunTransform.position;
						anotherGrab.withHandTransform.rotation = gunGuide.gunTransform.rotation;
					}else {
						numberOfHandGrabGun = 0;
					}
				}
				isGrabing = false;
				gunGuide.isGrabed = false;
				myGrabTransform = null;
				gunGuide.handGrab = null;
				gunGuide = null;
                COUNT = 0;
                t = true;
                
			}
		}
	}

	void enableCollider () {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 3; j++) {

				handTransform.GetChild (i).GetChild (j).GetComponent<CapsuleCollider> ().enabled = true;
			}
			myToucherContainer.SetFingerTouch (i, false);
		}
	}

	void disableCollider () {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 3; j++) {
				handTransform.GetChild (i).GetChild (j).GetComponent<CapsuleCollider> ().enabled = false;
			}
		}
	}
}